// import './App.css';
import Vvod from './Components/index';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Container, Row, Col } from 'react-bootstrap';

const API_KEY = 'tgWrGbAq8XdprDbZnS3oj7H27PtSqYloBNYvzWRN';




function App() {
  
  getPhoto = async(e) =>{
    e.preventDefault();
    const earth_date = e.target.elements.earth_date1.value;
    const api_url = await fetch(`https://api.nasa.gov/mars-photos/api/v1/rovers/curiosity/photos?earth_date=${earth_date}&api_key=${API_KEY}`);
    const data = await api_url.json();
    console.log(data);
  }

  return (
    <>

    
     <Vvod  photoMethod={this.getPhoto} /> 
   
  
    </>
  );
}

export default App;
