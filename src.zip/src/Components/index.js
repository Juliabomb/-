import React, {Component} from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import { Form, Button } from 'react-bootstrap';
import './styles.css';




export default function Vvod(props) { 
    

    return(
        
        <div class="container h-100 conteiner1">
            <div class="  row h-100 justify-content-center align-items-center text-center">
        
        
        <form  onSubmit={this.props.photoMethod} class="col-12 border rounded p-4 bg-white shadow p-3 mb-5 bg-light rounded">
            
           <p class = 'Label1 alert-secondary ' ><strong> Выберите вид марсохода</strong>
           <select name="Marsohod" class="custom-select marsohod">
                <option selected value="Curiosity">Curiosity</option>
                <option selected value="Opportunity" >Opportunity</option>
                <option selected="Spirit">Spirit</option>
            </select> 
           </p>
            


           <p class = 'Label2 alert-secondary'><strong> Выберите тип камеры</strong>
           <select name="Camera" class="custom-select camera">
                <option selected value="FHAZ">FHAZ</option>
                <option selected value="RHAZ" >RHAZ</option>
                <option selected value="MAST">MAST</option>
                <option selected value="CHEMCAM">CHEMCAM</option>
                <option selected value="MAHLI" >MAHLI</option>
                <option selected value="MARDI">MARDI</option>
                <option selected value="NAVCAM">NAVCAM</option>
                <option selected value="PANCAM">PANCAM</option>
                <option selected value="MINITES" >MINITES</option> 
            </select> 
           </p>
           
           <p class = 'Label3 alert-secondary'><strong> Выберите дату</strong>
             <Form.Control type ="text" name = "earth_date1"  placeholder="ГГГГ.ММ.ДД"/>
           </p>
        
           <Button class="btn btn-outline-dark" value="Отправить" > Поиск</Button> 
           
            
        </form>    
        </div>

        </div>
    )


}